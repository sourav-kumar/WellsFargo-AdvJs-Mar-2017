	var evtObject = {};
function radio(evName) {
	if(!evName) {
		return "Event Name is missing";
	}
	if(!evtObject[evName]) {
		evtObject[evName] = [];
	}

	var subscribe = function(func) {
		evtObject[evName].push(func);
		return this;
	};
	var broadcast = function(data) {
		for ( var k in evtObject) {
			if( k === evName) {
				evtObject[evName].forEach(function(func){
					func.call(this, data);
				});
			}
		}
		return this;
	};
	var unsubscribe = function(func) {
		var index = evtObject[evName].indexOf('func');
		evtObject[evName].splice(index, 1);
		return this;
	};
	return {
		evtObject : evtObject,
		subscribe : subscribe,
		broadcast: broadcast,
		unsubscribe: unsubscribe
	};
}