var x = {
	a:'asd',
	b:'bsd'
}

function Y(){
	this.c = "sourav"
}

function extend(dest, source) {
	for( var k in source) {
		if(source.hasOwnProperty(k)) {
			dest[k] = source[k];
		}
	}
	return dest;
}

var obj1 = extend(Y.prototype, x);