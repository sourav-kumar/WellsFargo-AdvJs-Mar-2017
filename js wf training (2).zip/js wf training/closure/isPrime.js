// function isPrime(value) {
// 	var ans = [];
// 	if(ans[value] != null) {
// 		return ans[value];
// 	}
// 	for(var i =2; i<value; i++) {
// 		console.log('assa');
// 		if(value % i == 0) {
// 			ans[value] = false
// 			return false;
// 		}
// 	}
// 	ans[value] = value > 1;
// 	return ans[value]
// }
var isPrime = (function() {
	var cache = {};
	 return function isPrime(n) {
		if (typeof cache[n] !== 'undefined')
			return cache[n];
		console.log("processing");
		if( n <= 3) {
			cache[n] = true;
		}
		else {
			cache[n] = true;
			for (var i = 2; i < (n/2); i++) {
				if(n%i == 0) {
					cache[n] = false;
					break;
				}
			}
			
		}
		return cache[n];
	};
})();

//generalize funciton

function memoize(algoFn) {
	var cache = {};
	return function (n) {
		// body...
		if (typeof cache[n] !== 'undefined')
			return cache[n];
		console.log("processing", n);
		cache[n] = algoFn(n);
		return cache[n];
	}
}

var isPrime = memoize(function(n) {
	if(n<= 3)
		return true;
	for (var i = 2; i < n/2; i++) {
		if(n % i === 0) {
			return false;
		}
	}
	return true;
})

//if agloFn has two or more arguments
function memoize(algoFn) {
	var cache = {};
	return function (n) {
		// body...
		var key = JSON.stringify(arguments);
		if (typeof cache[key] !== 'undefined')
			return cache[key];
		console.log("processing", key);
		cache[key] = algoFn.apply(this, arguments);
		return cache[key];
	}
}

var cacheAdd = memoize(function(x,y){
	return x+ y;
})